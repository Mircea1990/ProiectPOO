#ifndef BILETE_UTIL_H
#define BILETE_UTIL_H

const char *intToString(int num);

#endif //BILETE_UTIL_H
